# audio-compressor
Audio Compressor using Peak and RMS Detection, written in MATLAB

## Running the Test Program
In order to see the compressor working in a number of different ways, open simpleCompressorTest.m in MATLAB and run this file. To hear the various sounds after compression, uncomment the sound lines in the file by removing the % sign from the beginning of the line.
